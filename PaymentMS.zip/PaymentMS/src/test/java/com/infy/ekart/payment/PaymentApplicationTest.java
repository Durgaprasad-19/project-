package com.infy.ekart.payment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.infy.ekart.payment.dto.CardDTO;
import com.infy.ekart.payment.dto.OrderDTO;
import com.infy.ekart.payment.dto.TransactionDTO;
import com.infy.ekart.payment.dto.TransactionStatus;
import com.infy.ekart.payment.entity.Card;
import com.infy.ekart.payment.exception.EKartPaymentException;
import com.infy.ekart.payment.exception.PayOrderFallbackException;
import com.infy.ekart.payment.repository.CardRepository;
import com.infy.ekart.payment.repository.TransactionRepository;
import com.infy.ekart.payment.service.PaymentService;
import com.infy.ekart.payment.service.PaymentServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PaymentApplicationTest {

	@InjectMocks
	PaymentService paymentService = new PaymentServiceImpl();

	@Mock
	private CardRepository cardRepository;

	@Mock
	private TransactionRepository transactionRepository;
	
	@Test
	void updateCustomerCardValidTest() throws EKartPaymentException {

		Card card = new Card();
		card.setCardId(1);
		card.setNameOnCard("test");
		card.setCardType("savings");
		card.setCardNumber("1234123412341234");
		card.setExpiryDate("10/22");
		card.setCustomerEmailId("test@gmail.com");

		CardDTO cardDTO = new CardDTO();
		cardDTO.setCardId(100);

		Mockito.when(cardRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(card));
		Assertions.assertDoesNotThrow(() -> paymentService.updateCustomerCard(cardDTO));
	}

	@Test
	void updateCustomerCardInValidTest() throws EKartPaymentException {
		CardDTO cardDTO = new CardDTO();
		Mockito.when(cardRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		EKartPaymentException exp = Assertions.assertThrows(EKartPaymentException.class,
				() -> paymentService.updateCustomerCard(cardDTO));
		Assertions.assertEquals("PaymentService.CARD_NOT_FOUND", exp.getMessage());
	}

	@Test
	void getCardValidTest() throws EKartPaymentException {
		Card card = new Card();
		card.setCardID(100);
		Mockito.when(cardRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(card));
		CardDTO cardDTO = paymentService.getCard(card.getCardID());
		Assertions.assertEquals(card.getCardID(), cardDTO.getCardId());
	}

	@Test
	void getCardInValidTest() throws EKartPaymentException {
		Integer cardId = 100;
		Mockito.when(cardRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		Exception exp = Assertions.assertThrows(EKartPaymentException.class, () -> paymentService.getCard(cardId));
		Assertions.assertEquals("PaymentService.CARD_NOT_FOUND", exp.getMessage());
	}

	@Test
	void addTransactionInValidTest1() {
		TransactionDTO transactionDTO = new TransactionDTO();
		transactionDTO.setTransactionStatus(TransactionStatus.TRANSACTION_FAILED);
		Throwable exp = Assertions.assertThrows(PayOrderFallbackException.class,
				() -> paymentService.addTransaction(transactionDTO));
		Assertions.assertEquals("Payment.TRANSACTION_FAILED_CVV_NOT_MATCHING", exp.getMessage());
	}

	@Test
	void addTransactionInvalidTest1() throws EKartPaymentException {
		TransactionDTO transactionDTO = new TransactionDTO();
		CardDTO card = new CardDTO();
		card.setCardId(100);
		transactionDTO.setCard(card);
		OrderDTO order = new OrderDTO();
		order.setOrderId(111);
		transactionDTO.setOrder(order);
		transactionDTO.setTotalPrice(100.5d);
		transactionDTO.setTransactionDate(LocalDateTime.now());
		transactionDTO.setTransactionId(112);
		transactionDTO.setTransactionStatus(TransactionStatus.TRANSACTION_SUCCESS);
		Assertions.assertDoesNotThrow(() -> paymentService.addTransaction(transactionDTO));
	}

	@Test
	void authenticatePaymentOnInValidTest() throws EKartPaymentException {
		String customerEmailId = "tom@infosys.com";
		TransactionDTO transactionDTO = new TransactionDTO();
		CardDTO card = new CardDTO();
		card.setCardId(100);
		transactionDTO.setCard(card);
		OrderDTO order = new OrderDTO();
		order.setOrderId(111);
		order.setCustomerEmailId("tom@infosys.com");
		order.setOrderStatus("CANCELLED");
		transactionDTO.setOrder(order);
		transactionDTO.setTotalPrice(100.5d);
		transactionDTO.setTransactionDate(LocalDateTime.now());
		transactionDTO.setTransactionId(112);
		transactionDTO.setTransactionStatus(TransactionStatus.TRANSACTION_SUCCESS);
		Exception e = Assertions.assertThrows(EKartPaymentException.class,
				() -> paymentService.authenticatePayment(customerEmailId, transactionDTO));
		Assertions.assertEquals("PaymentService.TRANSACTION_ALREADY_DONE", e.getMessage());
	}

	@Test
	void authenticatePaymentOnInValidTest1() throws EKartPaymentException {
		String customerEmailId = "tom@infosys.com";
		TransactionDTO transactionDTO = new TransactionDTO();
		CardDTO card = new CardDTO();
		card.setCardId(100);
		transactionDTO.setCard(card);
		OrderDTO order = new OrderDTO();
		order.setOrderId(111);
		order.setCustomerEmailId("tom@infosys.com");
		order.setOrderStatus("CANCELLED");
		transactionDTO.setOrder(order);
		transactionDTO.setTotalPrice(100.5d);
		transactionDTO.setTransactionDate(LocalDateTime.now());
		transactionDTO.setTransactionId(112);
		transactionDTO.setTransactionStatus(TransactionStatus.TRANSACTION_SUCCESS);
		Exception e = Assertions.assertThrows(EKartPaymentException.class,
				() -> paymentService.authenticatePayment(customerEmailId, transactionDTO));
		Assertions.assertEquals("PaymentService.TRANSACTION_ALREADY_DONE", e.getMessage());

	}

	@Test
	void authenticatePaymentInValidTest2() throws EKartPaymentException {
		String customerEmailId = "tom@infosys.com";
		TransactionDTO transactionDTO = new TransactionDTO();
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setCustomerEmailId("tom@infosys.com");
		orderDTO.setOrderStatus("PLACED");
		transactionDTO.setOrder(orderDTO);
		CardDTO cardDTO = new CardDTO();
		cardDTO.setCardId(1234);
		cardDTO.setCustomerEmailId("Customer@infy.com");
		transactionDTO.setCard(cardDTO);
		cardDTO.setCustomerEmailId("Customer@infy.com");
		transactionDTO.setCard(cardDTO);

		Card card = new Card();
		card.setCardType("CREDIT_CARD");
		card.setExpiryDate("10/22");
		card.setNameOnCard("AIM");
		card.setCvv("466");
		card.setCardType("6642150005012186");
		card.setCardNumber("0c658eb5d61e88c86f37613342bbce6cbf278a9a86ba6514dc7e5c205f76c99f");
		card.setExpiryDate("10/22");
		card.setCustomerEmailId("Customer@infy.com");

		Mockito.when(cardRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(card));

		Exception e = Assertions.assertThrows(EKartPaymentException.class,
				() -> paymentService.authenticatePayment(customerEmailId, transactionDTO));
		Assertions.assertEquals("PaymentService.CARD_DOES_NOT_BELONGS", e.getMessage());

	}

}
