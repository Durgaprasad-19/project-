package com.infy.ekart.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.ekart.payment.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

}
